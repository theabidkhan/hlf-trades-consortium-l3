export interface Trade {
    Record:any;
}
