export interface User {
    Record:any;
    UserID:any;
    UserName:any;

    
}