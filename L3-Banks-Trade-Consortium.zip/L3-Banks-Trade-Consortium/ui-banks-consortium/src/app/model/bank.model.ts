export interface Bank {
    Record:any;
}