export class ApiResponse {
  success:boolean;
  message:any;
  token: any;
  secret: any;
  result: any;
  status:any;
  data:any;
  UserID:any;
}
