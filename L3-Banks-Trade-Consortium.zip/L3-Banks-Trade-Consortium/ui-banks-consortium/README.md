# Angular8Demo

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 8.0.6.

## Other Angular Resources

[Spring Boot Angular 8](https://www.devglan.com/spring-boot/spring-boot-angular-8-example)

[Angular 7 CRUD Example](https://www.devglan.com/angular/angular-7-crud-example)

[Angular 6 CRUD](https://www.devglan.com/angular/angular-6-example)

[Typescript Tutorial](https://www.devglan.com/angular/typescript-tutorial)

[Angular Multiple File Upload](https://www.devglan.com/angular/angular-multiple-file-upload)

[Angular Universal Server Side Rendering](https://www.devglan.com/angular/angular-universal-server-side-rendering)

[Spring Boot Angular Captcha](https://www.devglan.com/angular/spring-boot-angular-captcha)

[Deploying Angular App on Nginx](https://www.devglan.com/angular/deploy-angular-app-nginx)


